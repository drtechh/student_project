from student import *

name = input("Enter student name: ")
grades = [20, 15]

average = avg(grades)
print("student:", name)
print("Avg =", average)
print("max =", maximum(grades))
print("status =", check_status(average))
